//To Implement: Google Reader -> Instapaper

chrome.extension.onRequest.addListener(function(req,sender,callback) {
  if(document.getElementById('current-entry')) {
  } else {
  }
});