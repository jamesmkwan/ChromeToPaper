var icons= {
  'default':{
    'name':'Default',
    'desc':'',
    'prev':'icon128.png'
  },
  'classic':{
    'name':'Classic',
    'desc':'Old icon for those who preferred it',
    'prev':'icon128.png'
  },
  'transparent':{
    'name':'Transparent',
    'prev':'icon128.png'
  },
  'green':{
    'name':'Green (user submitted)',
    'desc':'User did not request for any acknowledgement',
    'prev':'icon128.png'
  }
};